# Copilot instructions for ShopReel

## Source of truth

- Read `docs/SPEC.md` and its canonical base specification before any task.
- Apply the binding amendments in `docs/SPEC.md` where they conflict with the
  base specification.
- Do not contradict the specification. If a requirement is still unclear,
  ask before coding.
- Do only the requested task; avoid unrelated refactors.

## Hard constraint: zero running cost

- Use only services in the specification's stack table.
- Never store media in the database. Store stable R2 object keys and
  replaceable delivery URLs only.
- Never load unbounded lists; paginate everything.
- Route storage and video access through `StorageProvider` and `VideoProvider`.
- Treat the configured aggregate R2 safety threshold as a hard upload
  kill-switch boundary.

## Security and data

- TypeScript must remain strict; do not use `any` or `@ts-ignore`.
- Enable RLS on every table in the same migration that creates it.
- The browser may use only the Supabase anon key. Never expose service or R2
  credentials.
- Use RPCs for validation, rate limiting, counters, ownership-sensitive
  changes, cross-user effects, and admin operations.
- The `admins` table is the sole source of admin authority. Clients cannot
  mutate it or profile moderation fields.
- Every `SECURITY DEFINER` function sets a fixed `search_path`, derives the
  caller from `auth.uid()`, and revokes public execution where required.
- Use stable error categories: `unauthenticated`, `forbidden`, `not_found`,
  `invalid_input`, `rate_limited`, and `conflict`.
- Escape every user-controlled value in share HTML. Never use
  `dangerouslySetInnerHTML` with user content.
- Jobs must be idempotent. Delete R2 objects before deleting their database
  references, and retain a retryable record when storage deletion fails.

## UI and accessibility

- Mobile-first; test at 360px width.
- Icon-only buttons need accessible labels and all tap targets are at least
  44px.
- Respect `prefers-reduced-motion`, provide non-gesture alternatives, and
  manage focus in sheets/dialogs.
- Every screen has loading, empty, and error states.
- Only the active reel and its next neighbour mount a `<video>`.
- Lazy-load ffmpeg, comments, admin, and upload code.
- Put all user-facing strings in English and Hindi i18n resources.

## Required validation

- Add happy-path and failure-path tests for changed behavior.
- Database changes require RLS isolation tests.
- Test malicious affiliate hosts, duplicate/race-prone RPC calls, quota
  boundaries, admin rejection, hard-delete ordering, and share-page escaping.
- Run the smallest relevant lint, typecheck, and test commands after changes.
